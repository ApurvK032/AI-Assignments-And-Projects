# warehouse_starter/sim.py
from __future__ import annotations
from typing import List, Tuple, Optional, Dict
from collections import deque, defaultdict
import random
from config import Coord, NEI, Config
from env import WarehouseState
import random

# -------- Orders (Zipf) --------
class OrderSampler:
    """Samples item IDs with Zipf-like popularity (few very popular items)."""
    def __init__(self, n_shelves: int, k: int, alpha: float, rng: random.Random):
        self.ids = list(range(n_shelves))
        self.k = k
        self.rng = rng
        ranks = list(range(1, n_shelves+1))
        weights = [1.0/(r**alpha) for r in ranks]
        Z = sum(weights)
        self.probs = [w/Z for w in weights]
    def sample(self) -> List[int]:
        return [self.rng.choices(self.ids, weights=self.probs, k=1)[0] for _ in range(self.k)]

# -------- Geometry + BFS --------
def passable(cell: str) -> bool:
    return cell == '.' or cell.startswith('P')

def dir_allowed(r0: int, c0: int, r1: int, c1: int, cfg: Config) -> bool:
    if not cfg.ge_one_way:
        return True
    dr, dc = r1 - r0, c1 - c0
    if cfg.ge_row_dir == "even_right":
        if r0 % 2 == 0 and dc < 0: return False
        if r0 % 2 == 1 and dc > 0: return False
    elif cfg.ge_row_dir == "even_left":
        if r0 % 2 == 0 and dc > 0: return False
        if r0 % 2 == 1 and dc < 0: return False
    if cfg.ge_col_dir == "up_only" and dr > 0: return False
    if cfg.ge_col_dir == "down_only" and dr < 0: return False
    if cfg.ge_col_dir == "alt_up_down":
        if c0 % 2 == 0 and dr > 0: return False
        if c0 % 2 == 1 and dr < 0: return False
    return True

def bfs(grid: List[List[str]], start: Coord, goal: Coord, cfg: Config) -> Optional[List[Coord]]:
    """Shortest path (4-neighborhood). We *allow* stepping onto the goal even if it's a shelf."""
    R, C = len(grid), len(grid[0])
    q = deque([start]); prev = {start: None}
    while q:
        r, c = q.popleft()
        if (r, c) == goal: break
        for dr, dc in NEI:
            rr, cc = r + dr, c + dc
            if 0 <= rr < R and 0 <= cc < C and (rr,cc) not in prev:
                if ((rr,cc) == goal) or (passable(grid[rr][cc]) and dir_allowed(r,c,rr,cc,cfg)):
                    prev[(rr, cc)] = (r, c); q.append((rr, cc))
    if goal not in prev: return None
    path = []; cur = goal
    while cur is not None:
        path.append(cur); cur = prev[cur]
    path.reverse(); return path

def build_tour(grid: List[List[str]], station: Coord, items: List[Coord], cfg: Config,
               track_picks: bool = False):
    """Greedy nearest-neighbor tour: station → items → station."""
    cur = station; remaining = items[:]
    path: List[Coord] = [cur]; picks: List[Tuple[int, Coord]] = []
    while remaining:
        best = None; bestp = None
        for it in remaining:
            p = bfs(grid, cur, it, cfg)
            if p is None: return None
            if bestp is None or len(p) < len(bestp):
                best, bestp = it, p
        path += bestp[1:]
        if track_picks: picks.append((len(path)-1, best))
        cur = best; remaining.remove(best)
    back = bfs(grid, cur, station, cfg)
    if back is None: return None
    path += back[1:]
    return (path, picks) if track_picks else path

# -------- Evaluation / Simulation --------
def evaluate(state: WarehouseState, cfg: Config, seed: int):
    """Compute score and metrics over cfg.orders (no animation)."""
    return _simulate(state, cfg, seed, collect_paths=False)

def simulate_with_paths(state: WarehouseState, cfg: Config, seed: int, limit_orders: int):
    """Short run (subset of orders) that returns paths + pick events for animation."""
    return _simulate(state, cfg, seed, collect_paths=True, limit_orders=limit_orders)

def _simulate(state: WarehouseState, cfg: Config, seed: int, collect_paths: bool, limit_orders: int | None = None):
    rng = random.Random(seed)
    n_shelves = len(state.shelves)
    sampler = OrderSampler(n_shelves, cfg.items_per_order, cfg.zipf_alpha, rng)
    id2coord = {i: state.shelves[i] for i in range(n_shelves)}

    per_station_times = defaultdict(list)
    heat = [[0 for _ in range(state.cols)] for _ in range(state.rows)]
    paths: List[List[Coord]] = []
    picks_per_order: List[List[Tuple[int, Coord]]] = []

    total_dist = 0; penalty = 0
    total_orders = cfg.orders if not collect_paths else min(cfg.orders, limit_orders or cfg.orders)

    for k in range(total_orders):
        sid = k % max(1, len(state.stations))
        station = state.stations[sid]
        items = sampler.sample()
        coords = [id2coord[i] for i in set(items)]

        res = build_tour(state.grid, station, coords, cfg, track_picks=collect_paths)
        if res is None:
            penalty += 500
            if collect_paths: paths.append([]); picks_per_order.append([])
            continue

        if collect_paths:
            p, pe = res; picks_per_order.append(pe); paths.append(p)
        else:
            p = res  # type: ignore

        dist = len(p) - 1; total_dist += dist
        per_station_times[f"P{sid}"].append(dist)
        for (r,c) in p: heat[r][c] += 1

    # If we animated a subset, finish heat/metrics for the rest quickly (no paths/picks)
    if collect_paths and total_orders < cfg.orders:
        for k in range(total_orders, cfg.orders):
            sid = k % max(1, len(state.stations)); station = state.stations[sid]
            items = sampler.sample(); coords = [id2coord[i] for i in set(items)]
            p = build_tour(state.grid, station, coords, cfg, track_picks=False)
            if p is None: penalty += 500; continue
            dist = len(p) - 1; total_dist += dist
            per_station_times[f"P{sid}"].append(dist)
            for (r,c) in p: heat[r][c] += 1

    # ------------------------------------------------------------------
    #   STUDENT TODO: DEFINE YOUR OBJECTIVE HERE (smaller score is better)
    # ------------------------------------------------------------------
    # Implemented: simple normalized objective with three parts.
    # J1 = average distance per order
    # J2 = congestion = average of (heat^2) over cells
    # J3 = fairness = variance of per-station average tour length
    # Score = w1*J1 + w2*J2 + w3*J3 + penalty



    # Compute average distance per order
    avg_dist = total_dist / max(1, cfg.orders)

    # Congestion: count how many cells were visited more than once
    overlap_penalty = 0
    for r in range(state.rows):
        for c in range(state.cols):
            if heat[r][c] > 1:
                overlap_penalty += (heat[r][c] - 1)

    # Fairness: variance in per-station average times
    avg_times = [sum(t) / max(1, len(t)) for t in per_station_times.values()]
    fairness = 0.0
    if avg_times:
        mean_time = sum(avg_times) / len(avg_times)
        fairness = sum((x - mean_time)**2 for x in avg_times) / len(avg_times)

    # Weighted total score (lower is better)
    score = cfg.w1 * avg_dist + cfg.w2 * overlap_penalty + cfg.w3 * fairness + penalty
    # 

    metrics = {
        "avg_distance": avg_dist,
        "overlap_penalty": overlap_penalty,
        "fairness": fairness,
        "penalty": penalty,
        "total_orders": cfg.orders,
    }

    if collect_paths:
        return score, metrics, per_station_times, heat, paths, picks_per_order
    else:
        return score, metrics, per_station_times, heat, []
