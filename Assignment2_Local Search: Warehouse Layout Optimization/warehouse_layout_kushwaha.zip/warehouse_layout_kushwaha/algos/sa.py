# algos/sa.py — simple simulated annealing
import random, math
from config import Config
from env import (
    artery_mask,
    all_artery_cells,
    all_non_artery_cells,
    build_state_from_choices,
)
from sim import evaluate


def simulated_annealing(
    cfg: Config, steps: int = 4000, T0: float = 2.0, alpha: float = 0.995, seed: int | None = None
):
    rng = random.Random(cfg.seed if seed is None else seed)

    A = artery_mask(cfg.rows, cfg.cols)
    AR = all_artery_cells(A)
    NA = all_non_artery_cells(A)
    nA, nN = len(AR), len(NA)

    def random_state():
        sidx = sorted(rng.sample(range(nA), cfg.n_stations))
        eidx = sorted(rng.sample(range(nN), cfg.target_non_artery_empties))
        return sidx, eidx

    def to_layout(st):
        sidx, eidx = st
        return build_state_from_choices(cfg, sidx, eidx)

    def score(st):
        layout = to_layout(st)
        return evaluate(layout, cfg, cfg.seed)[0]

    def random_neighbor(st):
        sidx = st[0][:]
        eidx = st[1][:]

        if rng.random() < 0.5 and sidx:
            used = set(sidx)
            i = rng.randrange(len(sidx))
            cand = [x for x in range(nA) if x not in used]
            if cand:
                sidx[i] = rng.choice(cand)
                sidx.sort()
        else:
            if eidx:
                used = set(eidx)
                j = rng.randrange(len(eidx))
                cand = [x for x in range(nN) if x not in used]
                if cand:
                    eidx[j] = rng.choice(cand)
                    eidx.sort()

        return sidx, eidx

    current = random_state()
    current_score = score(current)
    best = current
    best_score = current_score
    T = float(T0)

    for _ in range(steps):
        nb = random_neighbor(current)
        nb_sc = score(nb)

        if nb_sc < current_score:
            current, current_score = nb, nb_sc
            if current_score < best_score:
                best, best_score = current, current_score
        else:
            delta = nb_sc - current_score
            if T > 1e-12:
                prob = math.exp(-delta / T)
                if rng.random() < prob:
                    current, current_score = nb, nb_sc

        T *= alpha
        if T < 1e-12:
            T = 1e-12

    best_layout = to_layout(best)
    info = {"steps": steps, "T0": T0, "alpha": alpha}
    return best_layout, best_score, info
