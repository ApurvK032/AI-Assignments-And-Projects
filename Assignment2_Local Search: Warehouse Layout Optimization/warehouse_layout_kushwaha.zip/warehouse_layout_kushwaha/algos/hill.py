# algos/hill.py — simple hill climbing with optional restarts
import random
from config import Config
from env import (
    artery_mask,
    all_artery_cells,
    all_non_artery_cells,
    build_state_from_choices,
)
from sim import evaluate


# State = (station_idxs, empty_idxs)
def hill_climb(cfg: Config, steps: int = 4000, restarts: int = 0, seed: int | None = None):
    rng = random.Random(cfg.seed if seed is None else seed)

    A = artery_mask(cfg.rows, cfg.cols)
    AR = all_artery_cells(A)
    NA = all_non_artery_cells(A)
    nA, nN = len(AR), len(NA)

    def random_state():
        sidx = sorted(rng.sample(range(nA), cfg.n_stations))
        eidx = sorted(rng.sample(range(nN), cfg.target_non_artery_empties))
        return sidx, eidx

    def to_layout(st):
        sidx, eidx = st
        return build_state_from_choices(cfg, sidx, eidx)

    def score(st):
        layout = to_layout(st)
        return evaluate(layout, cfg, cfg.seed)[0]

    def random_neighbor(st):
        sidx = st[0][:]
        eidx = st[1][:]

        if rng.random() < 0.5 and sidx:
            used = set(sidx)
            i = rng.randrange(len(sidx))
            cand = [x for x in range(nA) if x not in used]
            if cand:
                sidx[i] = rng.choice(cand)
                sidx.sort()
        else:
            if eidx:
                used = set(eidx)
                j = rng.randrange(len(eidx))
                cand = [x for x in range(nN) if x not in used]
                if cand:
                    eidx[j] = rng.choice(cand)
                    eidx.sort()

        return sidx, eidx

    def run_once():
        cur = random_state()
        cur_sc = score(cur)
        for _ in range(steps):
            nb = random_neighbor(cur)
            nb_sc = score(nb)
            if nb_sc < cur_sc:
                cur, cur_sc = nb, nb_sc
        return cur, cur_sc

    best_state, best_score = run_once()
    for _ in range(restarts):
        st, sc = run_once()
        if sc < best_score:
            best_state, best_score = st, sc

    best_layout = to_layout(best_state)
    info = {"steps": steps, "restarts": restarts}
    return best_layout, best_score, info
