# algos/ga.py — simple genetic algorithm
import random
from config import Config
from env import (
    artery_mask,
    all_artery_cells,
    all_non_artery_cells,
    build_state_from_choices,
)
from sim import evaluate


def genetic_algorithm(
    cfg: Config,
    pop_size: int = 20,
    generations: int = 50,
    seed: int | None = None,
    mutation_rate: float = 0.2,
):
    rng = random.Random(cfg.seed if seed is None else seed)

    A = artery_mask(cfg.rows, cfg.cols)
    AR = all_artery_cells(A)
    NA = all_non_artery_cells(A)
    nA, nN = len(AR), len(NA)

    def random_state():
        sidx = sorted(rng.sample(range(nA), cfg.n_stations))
        eidx = sorted(rng.sample(range(nN), cfg.target_non_artery_empties))
        return sidx, eidx

    def to_layout(st):
        sidx, eidx = st
        return build_state_from_choices(cfg, sidx, eidx)

    def score(st):
        layout = to_layout(st)
        return evaluate(layout, cfg, cfg.seed)[0]

    def crossover(a, b):
        sa, ea = a
        sb, eb = b

        def mix(L1, L2, size, domain):
            k = max(0, min(size, len(L1) // 2))
            child = list(L1[:k]) + list(L2)
            child = [x for x in child if 0 <= x < domain]
            child = sorted(list(dict.fromkeys(child)))
            if len(child) > size:
                child = child[:size]
            elif len(child) < size:
                used = set(child)
                pool = [x for x in range(domain) if x not in used]
                rng.shuffle(pool)
                child += pool[: size - len(child)]
            return sorted(child)

        return (
            mix(sa, sb, cfg.n_stations, nA),
            mix(ea, eb, cfg.target_non_artery_empties, nN),
        )

    def mutate(st):
        sidx = st[0][:]
        eidx = st[1][:]
        if rng.random() < 0.5 and sidx:
            used = set(sidx)
            i = rng.randrange(len(sidx))
            cand = [x for x in range(nA) if x not in used]
            if cand:
                sidx[i] = rng.choice(cand)
                sidx.sort()
        if rng.random() < 0.5 and eidx:
            used = set(eidx)
            j = rng.randrange(len(eidx))
            cand = [x for x in range(nN) if x not in used]
            if cand:
                eidx[j] = rng.choice(cand)
                eidx.sort()
        return sidx, eidx

    # initial population
    population = [(random_state(), 0) for _ in range(pop_size)]
    population = [(st, score(st)) for st, _ in population]

    def pick_parent():
        i, j = rng.randrange(len(population)), rng.randrange(len(population))
        return population[i][0] if population[i][1] <= population[j][1] else population[j][0]

    best_state, best_score = min(population, key=lambda x: x[1])

    for _ in range(generations):
        new_pop = [(best_state, best_score)]  # keep best
        while len(new_pop) < pop_size:
            p1 = pick_parent()
            p2 = pick_parent()
            child = crossover(p1, p2)
            if rng.random() < mutation_rate:
                child = mutate(child)
            new_pop.append((child, score(child)))
        population = new_pop
        cand_state, cand_score = min(population, key=lambda x: x[1])
        if cand_score < best_score:
            best_state, best_score = cand_state, cand_score

    best_layout = to_layout(best_state)
    return best_layout, best_score
